package com.example.vectorplus; // <-- cambia por el paquete de tu proyecto

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    VectorPlus a, b;
    EditText ele, pos;
    RadioButton rbA;
    TextView tvA, tvB, tvRes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ele = findViewById(R.id.ele);
        pos = findViewById(R.id.pos);
        rbA = findViewById(R.id.rbA);
        tvA = findViewById(R.id.tvA);
        tvB = findViewById(R.id.tvB);
        tvRes = findViewById(R.id.tvRes);

        a = new VectorPlus(this);
        b = new VectorPlus(this);
        actualizar();
    }

    // Vector seleccionado (A o B)
    private VectorPlus actual() {
        return rbA.isChecked() ? a : b;
    }

    private void actualizar() {
        tvA.setText("A: " + a.toString());
        tvB.setText("B: " + b.toString());
    }

    // Lee un número de un EditText; devuelve null si está vacío
    private Integer leer(EditText et) {
        String s = et.getText().toString().trim();
        if (s.isEmpty()) {
            et.setError("Campo requerido");
            return null;
        }
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            et.setError("Número inválido");
            return null;
        }
    }

    public void eCrear(View view) {
        if (rbA.isChecked()) a = new VectorPlus(this);
        else b = new VectorPlus(this);
        tvRes.setText("");
        actualizar();
    }

    public void eAddElem(View view) {
        Integer e = leer(ele);
        if (e == null) return;
        actual().addElem(e);
        actualizar();
    }

    public void eInsElem(View view) {
        Integer e = leer(ele);
        Integer p = leer(pos);
        if (e == null || p == null) return;
        actual().insElem(p, e);
        actualizar();
    }

    public void eRemElem(View view) {
        Integer p = leer(pos);
        if (p == null) return;
        actual().remElem(p);
        actualizar();
    }

    public void eCortes(View view) {
        tvRes.setText("Cantidad de cortes de control: " + actual().cantidadCortes());
    }

    public void eEntreCortes(View view) {
        int[] g = actual().elementosEntreCortes();
        if (g.length == 0) {
            tvRes.setText("El vector está vacío");
            return;
        }
        StringBuilder sb = new StringBuilder("Elementos entre cortes:\n");
        for (int i = 0; i < g.length; i++)
            sb.append("Grupo ").append(i + 1).append(": ").append(g[i]).append("\n");
        tvRes.setText(sb.toString());
    }

    public void eDividir(View view) {
        VectorPlus pares = new VectorPlus(this);
        VectorPlus impares = new VectorPlus(this);
        actual().dividirParImpar(pares, impares);
        tvRes.setText("Pares: " + pares + "\nImpares: " + impares);
    }

    public void eIntercalar(View view) {
        VectorPlus r = a.intercalar(b);
        tvRes.setText("Intercalado (A y B): " + r);
    }

    public void ePurgar(View view) {
        actual().purgar();
        actualizar();
        tvRes.setText("Vector purgado");
    }

    public void eSalir(View view) {
        finish();
    }
}

