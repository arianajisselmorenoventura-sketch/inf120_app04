package com.example.vectorplus; // <-- cambia por el paquete de tu proyecto

import android.content.Context;
import android.widget.Toast;

public class VectorPlus {
    private final Context ctx;
    final int MAX_E = 1000;
    private int[] elem = new int[MAX_E];
    private int dim;

    public VectorPlus(Context ctx) {
        this.ctx = ctx;
        dim = -1;
        for (int i = 0; i < MAX_E; i++)
            elem[i] = 0;
    }

    public void ShowMessage(String msg) {
        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show();
    }

    // ---------- Operaciones base (como Implementación 2) ----------

    public int getDim() {
        return dim + 1;
    }

    public int getElem(int pos) {
        pos = pos - 1;
        if ((pos >= 0) && (pos <= dim))
            return elem[pos];
        else
            return -999;
    }

    public void setElem(int pos, int ele) {
        pos = pos - 1;
        if ((pos >= 0) && (pos <= dim))
            elem[pos] = ele;
        else
            ShowMessage("Fuera de Rango...");
    }

    public void addElem(int ele) {
        if (dim < MAX_E - 1) {
            dim++;
            elem[dim] = ele;
        } else
            ShowMessage("Almac. Lleno...");
    }

    public void insElem(int pos, int ele) {
        pos = pos - 1;
        if (dim < MAX_E - 1) {
            if ((pos >= 0) && (pos <= dim)) {
                for (int i = dim; i >= pos; i--)
                    elem[i + 1] = elem[i];
                elem[pos] = ele;
                dim++;
            } else
                ShowMessage("Fuera de Rango...");
        } else
            ShowMessage("Almac. Lleno...");
    }

    public void remElem(int pos) {
        pos = pos - 1;
        if ((pos >= 0) && (pos <= dim)) {
            for (int i = pos; i < dim; i++)
                elem[i] = elem[i + 1];
            dim--;
        } else
            ShowMessage("Fuera de Rango...");
    }

    // ---------- Operaciones con Cortes de Control ----------
    // Un grupo es una racha de elementos iguales consecutivos.
    // Hay un corte de control cada vez que el elemento cambia de valor.
    // Ej: [1,1,2,2,2,3] -> grupos {1,1} {2,2,2} {3}

    // 1) Cantidad de cortes de control (cantidad de grupos)
    public int cantidadCortes() {
        if (dim < 0) return 0;
        int cont = 1;
        for (int i = 1; i <= dim; i++)
            if (elem[i] != elem[i - 1])
                cont++;
        return cont;
    }

    // 2) Cantidad de elementos entre cortes de control (tamaño de cada grupo)
    public int[] elementosEntreCortes() {
        int n = cantidadCortes();
        int[] res = new int[n];
        if (n == 0) return res;
        int g = 0;
        res[0] = 1;
        for (int i = 1; i <= dim; i++) {
            if (elem[i] != elem[i - 1]) {
                g++;
                res[g] = 1;
            } else
                res[g]++;
        }
        return res;
    }

    // 3) Dividir el vector en dos: pares e impares (por valor)
    public void dividirParImpar(VectorPlus pares, VectorPlus impares) {
        for (int i = 0; i <= dim; i++) {
            if (elem[i] % 2 == 0)
                pares.addElem(elem[i]);
            else
                impares.addElem(elem[i]);
        }
    }

    // 4) Intercalar con otro vector: uno de A, uno de B, ...
    //    Si uno es más largo, el resto se agrega al final.
    public VectorPlus intercalar(VectorPlus b) {
        VectorPlus r = new VectorPlus(ctx);
        int i = 1, j = 1;
        while (i <= getDim() || j <= b.getDim()) {
            if (i <= getDim()) {
                r.addElem(getElem(i));
                i++;
            }
            if (j <= b.getDim()) {
                r.addElem(b.getElem(j));
                j++;
            }
        }
        return r;
    }

    // 5) Purgar: dejar un solo elemento por cada grupo (quita repetidos consecutivos)
    public void purgar() {
        if (dim < 0) return;
        int w = 0;
        for (int i = 1; i <= dim; i++) {
            if (elem[i] != elem[w]) {
                w++;
                elem[w] = elem[i];
            }
        }
        dim = w;
    }

    // Para mostrar el vector en pantalla
    @Override
    public String toString() {
        if (dim < 0) return "[ ]";
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i <= dim; i++) {
            sb.append(elem[i]);
            if (i < dim) sb.append(", ");
        }
        return sb.append("]").toString();
    }
}
